---------------------------------------------------------------
 Lovely Composer - Trial version
 ( Dungeon Witches 2 )

 (C) 2021-2023 1oogames, doc1oo
                                 100.circle.info@gmail.com
                                 https://twitter.com/1oo_games
                                 http://doc1oo.lsv.jp/
---------------------------------------------------------------


* Trial version restrictions

 - Song data cannot be saved (Also app settings)
   (The song data will be initialized even if you move to another song.)
 - Few sample songs
 - Display showing trial version

Others are basically the same as the paid version.


* How to Use

 [ Windows ]
   - Run "lovely_composer.exe".

 [ Linux ]
   - Set execute permission to "lovely_composer.bin" from
     GUI or Terminal.

        chmod u+x lovely_composer.bin

   - Run "lovely_composer.bin".

 [ Raspberry Pi ]
 
   - Run "lovely_composer" (Symbolic Link).

 [ Mac ]

*  The Mac version is not officially supported, is in beta, and  *
*  is not guaranteed to be available.                            *

1. Start the terminal and execute the following command to the folder
   created by extracting the zip. You will need to rewrite the file 
   path to your own.
  ( This is to remove the information that the file is downloaded from
    the Internet and avoid the inability to start due to security. 
    Please judge whether you can trust this application by yourself.)

   xattr -cr ~/Downloads/LovelyComposer_1.2.4_Mac_Beta/


2. Launch the app depending on your OS.

   macOS 11 or higher:
     - Run “macOS/lovely_composer.app”. 

   macOS 10.11 - 10.15 (OSX):
     - Run “macOS_10.x/lovely_composer_macos10.x.app”.


* How to Config

 [ Windows ]
   - Run "config.exe".

 [ Linux ]
   - Set a execute permission to "lovely_composer.bin" from
     GUI or Terminal.

        chmod u+x lovely_composer.bin

   - Run "config.bin".

 > Setting should be done in a state where the end of the
   Lovely Composer.
 > The setting will take effect when the next time of the
   LovelyComposer start.


* Sample music license

You are free to use the sample songs, but if you want to use
them, we recommend that you write the author's name to any
place.
Also, some songs are from 1oo_games' work "Dungeon Witches".


-- Sample Music (LC_USER folder) ----------------------------------

     0 ... Author: Shirahai Yu               Title: Stardust Parade!
     1 ... Author: mutuba                    Title: The Beginning of My Dream
     2 ... Author: tdhr                      Title: Doubtful Festival of the East
     3 ... Author: Nachi Aramaki             Title: Jackpot DE Isekai tensei
     4 ... Author: tikango                   Title: ancient
     5 ... Author: f@ct (facton)             Title: from the day you leave
     6 ... Author: Piemologic                Title: Farewell Journey
     7 ... Author: Polygon Planet            Title: Falling Star
     8 ... Author: hits                      Title: Moon Phase
     9 ... Author: gronnblade                Title: 64
    10 ... Author: Rwi                       Title: Samplified Lives
    11 ... Author: xapuyo                    Title: Minigolf
    12 ... Author: kamikuzu                  Title: Hungarian Dances No.5     Composer: Johannes Brahms
    13 ... Author: Cat lover                 Title: The Flea Waltz            Composer: Unknown
    14 ... Author: yktakaha4                 Title: yuzuyu
    15 ... Author: RayMaster                 Title: Move Forward To Be Alive
    16 ... Author: arisui                    Title: Bathypelagic
    17 ... Author: ParallelKylie             Title: Morph
    18 ... Author: Kocobe                    Title: Stellar Theme
    19 ... Author: TO-MAX                    Title: PeriodLC
    20 ... Author: umum                      Title: StepUp

    21 ... Author: yktakaha4                 Title: Uchu-now
    22 ... Author: チカンゴ                  Title: (Untitled)
    23 ... Author: えなじ～                  Title: Execute
    24 ... Author: tdhr                      Title: (Untitled)
    25 ... Author: 荒巻那智 (Nachi Aramaki)  Title: まどろむ未確認
    26 ... Author: f@ct                      Title: Fun days
    27 ... Author: 24appnet                  Title: (Original Song) The Other Day, I Met a Bear（Traditional American Song）
    28 ... Author: hits                      Title: Sylph's Steps
    29 ... Author: hits                      Title: Starry Drive
    30 ... Author: えなじ～                  Title: 帰り道のアンダンテ

    No. 31 to 33 ... Author: Hideaki
                      ( #33 Stephen Collins Foster / 33 Antonín Leopold Dvořák )

    No.34       ... Author: doc1oo
                      ( #34 Wolfgang Amadeus Mozart )



* Software License

Copyright of the original part of this software is located in
1oo_games and doc1oo. Redistribution of this software beyond
private use is not permitted.

This software is no warranty. 
The author or a copyright holder does not do any responsibility
about this software. 

This software uses the following software.

 - Python3
     - libcrypto
 - Pyxel
     - miniz-cpp
     - SDL2
     - SDL_image 2.0
         - libjpeg
         - libpng
         - libwebp
         - zlib
 - Nuitka
 - psutil
 - pytest
 - PySimpleGUI
 - mido
     - python-rtmidi
 - vorbis-tools
     - libvorbis
     - libvorbisenc
     - libogg
     - libiconv
     - libintl
     - libFLAC
 - opus-tools
     - libopus
     - libopusenc
     - libogg
     - libFLAC
     - opusfile
         - libssl(OpenSSL)
 - FLAC
     - libiconv
     - libFLAC
 - LAME (https://lame.sourceforge.io/)
     - libiconv
     - libwinpthread

 - libcrypto(OpenSSL)
 - libreadline
 - liblzma (XZ Utils)
 - libzstd (Zstandard)
 - libvorbisenc (libvorbis)
 - libmpdec


　 * See ./licenses/ for the original license text.


this software is based in part on the work of the Independent
JPEG Group.
