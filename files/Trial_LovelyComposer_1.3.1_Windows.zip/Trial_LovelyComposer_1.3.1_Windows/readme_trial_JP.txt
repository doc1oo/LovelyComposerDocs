---------------------------------------------------------------
 Lovely Composer 体験版
 ( Dungeon Witches 2 )

 (C) 2021-2023 1oogames, doc1oo
                                 100.circle.info@gmail.com
                                 https://twitter.com/1oo_games
                                 http://doc1oo.lsv.jp/
---------------------------------------------------------------

■ 体験版の制限

・曲データ等の保存が一切できない
　（アプリを終了しなくても、別の曲への移動等でも曲データが初期化されます。）
・サンプル曲が少ない
・体験版表示がある

その他は基本的に有償版と同じです。


■ 起動方法

 [ Windows ]
   - lovely_composer.exe を実行します。

 [ Linux ]
   - lovely_composer.bin に実行権限を設定します。
       - ファイルのプロパティから、もしくはターミナルを起動して以下を実行
            chmod u+x lovely_composer.bin

   - lovely_composer.bin を実行します。

 [ Raspberry Pi ]
 
   - "lovely_composer" を実行します。 (Symbolic Link)

 [ Mac ]

※ Mac版は公式にはサポートしていません。ベータ版であり、動作保証はありません。 ※

1. ターミナルを起動し、以下のコマンドをzipファイルを展開してできたフォルダに対して
　 実行します。ファイルパスはご自身の環境に合わせて変更する必要があります。
　（この操作は「このアプリケーションがインターネットからダウンロードされたものである」という
　　情報をファイルから除去し、OSのセキュリティ機能によって起動できない問題を回避させます。
　　このアプリケーションが信頼できるかをご自身で判断して、問題ない場合のみ実行してください。）

   xattr -cr ~/Downloads/LovelyComposer_1.2.4_Mac_Beta/


2. 使用中のOSに合わせてアプリを起動します

   macOS 11 以上の場合:
     - “macOS/lovely_composer.app” を実行します。

   macOS 10.11 〜 10.15 (OSX) の場合:
     - “macOS_10.x/lovely_composer_macos10.x.app” を実行します。
   

■ 設定ツールの起動方法

 [ Windows ]
   - config.exe を実行します。

 [ Linux ]
   - "config.bin" に実行権限を設定します。
       - ファイルのプロパティから、もしくはターミナルを起動して以下を実行
            chmod u+x lovely_composer.bin

   - config.bin を実行します。
   
   ※ 設定は lovely_composer.exe を起動していない時に行ってください。
   ※ 設定は次回起動時から反映されます。


■ サンプル曲のライセンス

サンプル曲の利用は自由ですが、使用する場合は下記の作者名を
いずれかの場所に表記することを推奨します。


・サンプル曲 (LC_USER) ------------

     0 ... 作者名: 白灰憂 (Shirahai Yu)      曲名: ほしくずパレード！(Stardust Parade!)
     1 ... 作者名: 六葉 (mutuba)             曲名: The Beginning of My Dream
     2 ... 作者名: tdhr                      曲名: 胡乱な東の祭 (Doubtful Festival of the East)
     3 ... 作者名: 荒巻那智 (Nachi Aramaki)  曲名: ジャックポットで異世界転生！？ (Jackpot DE Isekai tensei)
     4 ... 作者名: tikango                   曲名: いにしえ (ancient)
     5 ... 作者名: f@ct (facton)             曲名: おでかけ日和 (from the day you leave)
     6 ... 作者名: Piemologic                曲名: Farewell Journey
     7 ... 作者名: Polygon Planet            曲名: Falling Star
     8 ... 作者名: hits                      曲名: Moon Phase
     9 ... 作者名: gronnblade                曲名: 64
    10 ... 作者名: Rwi                       曲名: Samplified Lives
    11 ... 作者名: xapuyo                    曲名: Minigolf
    12 ... 作者名: かみくず (kamikuzu)       曲名: ハンガリー舞曲 第5番 (Hungarian Dances No.5)  作曲:ヨハネス・ブラームス (Johannes Brahms)
    13 ... 作者名: ねこ好き (Cat lover)      曲名: 蚤のワルツ (The Flea Waltz)  ※作曲者不詳 
    14 ... 作者名: yktakaha4                 曲名: ゆず湯 (yuzuyu)
    15 ... 作者名: レイマスター (RayMaster)  曲名: Move Forward To Be Alive
    16 ... 作者名: アリスイ (arisui)         曲名: Bathypelagic
    17 ... 作者名: ParallelKylie             曲名: Morph
    18 ... 作者名: Kocobe                    曲名: Stellar Theme
    19 ... 作者名: TO-MAX                    曲名: ピリオドのない旅へ(LC.version) (PeriodLC)
    20 ... 作者名: umum                      曲名: StepUp

    21 ... 作者名: yktakaha4      曲名: うちゅうなう
    22 ... 作者名: チカンゴ       曲名: （なし）
    23 ... 作者名: えなじ～       曲名: Execute
    24 ... 作者名: tdhr           曲名: （特にありません）
    25 ... 作者名: 荒巻那智       曲名: まどろむ未確認
    26 ... 作者名: f@ct           曲名: Fun days
    27 ... 作者名: にしあぷ       曲名: (原曲) The Other Day, I Met a Bear（アメリカ民謡）
    28 ... 作者名: hits           曲名: 風の足跡
    29 ... 作者名: hits           曲名: Starry Drive
    30 ... 作者名: えなじ～       曲名: 帰り道のアンダンテ

    31番 ～ 33番 ... 作者名: ひであき
                         ( #33 Stephen Collins Foster / Antonín Leopold Dvořák  )

    34番        ... 作者名: doc1oo
                         ( #34 Wolfgang Amadeus Mozart )


■ ソフトウェアライセンス

・このソフトウェアのオリジナル部分の著作権はいちまるまるゲームズ
　およびdoc1ooにあります。このソフトウェアの私的利用を超えた
　範囲での再配布は認められていません。

・このソフトウェアはすべて無保証です。作者または著作権者は
　このソフトウェアおよびその使用により起きた損害等について一切の
　責任を負いません。

・このソフトウェアは以下のソフトウェアを使用しています。

 - Python3
     - libcrypto
 - Pyxel
     - miniz-cpp
     - SDL2
     - SDL_image 2.0
         - libjpeg
         - libpng
         - libwebp
         - zlib
 - Nuitka
 - psutil
 - pytest
 - PySimpleGUI
 - mido
     - python-rtmidi
 - vorbis-tools
     - libvorbis
     - libvorbisenc
     - libogg
     - libiconv
     - libintl
     - libFLAC
 - opus-tools
     - libopus
     - libopusenc
     - libogg
     - libFLAC
     - opusfile
         - libssl(OpenSSL)
 - FLAC
     - libiconv
     - libFLAC
 - LAME (https://lame.sourceforge.io/)
     - libiconv
     - libwinpthread

 - libcrypto(OpenSSL)
 - libreadline
 - liblzma (XZ Utils)
 - libzstd (Zstandard)
 - libvorbisenc (libvorbis)
 - libmpdec

　※ライセンス原文は ./licenses/以下をご参照ください。

this software is based in part on the work of the Independent
JPEG Group.
