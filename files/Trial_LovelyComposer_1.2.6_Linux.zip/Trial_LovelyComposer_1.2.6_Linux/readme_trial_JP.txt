---------------------------------------------------------------
 Lovely Composer 体験版
 ( Dungeon Witches 2 )

 (C) 2021-2022 1oogames, doc1oo
                                 100.circle.info@gmail.com
                                 https://twitter.com/1oo_games
                                 http://doc1oo.lsv.jp/
---------------------------------------------------------------

■ 体験版の制限

・曲データ等の保存が一切できない
　（アプリを終了しなくても、別の曲への移動等でも曲データが初期化されます。）
・サンプル曲が少ない
・体験版表示がある

その他は基本的に有償版と同じです。


■ 起動方法

 [ Windows ]
   - lovely_composer.exe を実行します。

 [ Linux ]
   - lovely_composer.bin に実行権限を設定します。
       - ファイルのプロパティから、もしくはターミナルを起動して以下を実行
            chmod u+x lovely_composer.bin

   - lovely_composer.bin を実行します。

 [ Raspberry Pi ]
 
   - "lovely_composer" を実行します。 (Symbolic Link)

 [ Mac ]

※ Mac版は公式にはサポートしていません。ベータ版であり、動作保証はありません。 ※

1. ターミナルを起動し、以下のコマンドをzipファイルを展開してできたフォルダに対して
　 実行します。ファイルパスはご自身の環境に合わせて変更する必要があります。
　（この操作は「このアプリケーションがインターネットからダウンロードされたものである」という
　　情報をファイルから除去し、OSのセキュリティ機能によって起動できない問題を回避させます。
　　このアプリケーションが信頼できるかをご自身で判断して、問題ない場合のみ実行してください。）

   xattr -cr ~/Downloads/LovelyComposer_1.2.4_Mac_Beta/


2. 使用中のOSに合わせてアプリを起動します

   macOS 11 以上の場合:
     - “macOS/lovely_composer.app” を実行します。

   macOS 10.11 〜 10.15 (OSX) の場合:
     - “macOS_10.x/lovely_composer_macos10.x.app” を実行します。
   

■ 設定ツールの起動方法

 [ Windows ]
   - config.exe を実行します。

 [ Linux ]
   - "config.bin" に実行権限を設定します。
       - ファイルのプロパティから、もしくはターミナルを起動して以下を実行
            chmod u+x lovely_composer.bin

   - config.bin を実行します。
   
   ※ 設定は lovely_composer.exe を起動していない時に行ってください。
   ※ 設定は次回起動時から反映されます。


■ サンプル曲のライセンス

サンプル曲の利用は自由ですが、使用する場合は下記の作者名を
いずれかの場所に表記することを推奨します。


・サンプル曲 (LC_USER) ------------

     0番 ～ 2番 ... 作者名: ひであき
                         ( #2 Stephen Collins Foster
                           #2 Antonín Leopold Dvořák  )

     3番        ... 作者名: doc1oo
                         ( #3 Wolfgang Amadeus Mozart )

    16番 ... 作者名: yktakaha4      曲名: うちゅうなう
    17番 ... 作者名: チカンゴ       曲名: （なし）
    18番 ... 作者名: えなじ～       曲名: Execute
    19番 ... 作者名: tdhr           曲名: （特にありません）
    20番 ... 作者名: 荒巻那智       曲名: まどろむ未確認
    21番 ... 作者名: f@ct           曲名: Fun days
    22番 ... 作者名: にしあぷ       曲名: (原曲) The Other Day, I Met a Bear（アメリカ民謡）
    23番 ... 作者名: hits           曲名: 風の足跡
    24番 ... 作者名: hits           曲名: Starry Drive
    25番 ... 作者名: えなじ～       曲名: 帰り道のアンダンテ



■ ソフトウェアライセンス

・このソフトウェアのオリジナル部分の著作権はいちまるまるゲームズ
　およびdoc1ooにあります。このソフトウェアの私的利用を超えた
　範囲での再配布は認められていません。

・このソフトウェアはすべて無保証です。作者または著作権者は
　このソフトウェアおよびその使用により起きた損害等について一切の
　責任を負いません。

・このソフトウェアは以下のソフトウェアを使用しています。

 - Python3
     - libcrypto
 - Pyxel
     - miniz-cpp
     - SDL2
     - SDL_image 2.0
         - libjpeg
         - libpng
         - libwebp
         - zlib
 - Nuitka
 - psutil
 - pytest
 - PySimpleGUI
 - mido
     - python-rtmidi
 - vorbis-tools
     - libvorbis
     - libvorbisenc
     - libogg
     - libiconv
     - libintl
     - libFLAC
 - opus-tools
     - libopus
     - libopusenc
     - libogg
     - libFLAC
     - opusfile
         - libssl(OpenSSL)
 - FLAC
     - libiconv
     - libFLAC
 - LAME (https://lame.sourceforge.io/)
     - libiconv
     - libwinpthread

 - libcrypto(OpenSSL)
 - libreadline
 - liblzma (XZ Utils)
 - libzstd (Zstandard)
 - libvorbisenc (libvorbis)
 - libmpdec

　※ライセンス原文は ./licenses/以下をご参照ください。

this software is based in part on the work of the Independent
JPEG Group.
